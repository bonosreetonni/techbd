<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>TECHBD </span>ONLINE MARKET</h1>
									<h2>MAKE YOUR SHOPPING FLEXYBLE</h2>
									<p>Get Latest Online Gadgets at Universal Gadgets where you can get latest designs of phone covers, screen protector, selfie sticks and much more gaming equipment at affordable prices </p>
								
								</div>
								<div class="col-sm-6">
									<img src="<?php echo base_url() ?>asset/images/home/girl1.png" class="girl img-responsive" alt="" />
									<!--<img src="<?php echo base_url() ?>asset/images/home/pricing.png"  class="pricing" alt="" />-->
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>SKA</span>ONLINE SHOPPING</h1>
									<h2>100% Responsive Design</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
									<button type="button" class="btn btn-default get">Get it now</button>
								</div>
								<div class="col-sm-6">
									<img src="<?php echo base_url() ?>asset/images/home/girl2.jpg" class="girl img-responsive" alt="" />
									<img src="<?php echo base_url() ?>asset/images/home/pricing.png"  class="pricing" alt="" />
								</div>
							</div>
							
							<div class="item">
								<div class="col-sm-6">
									<h1><span>SKA</span>ONLINE SHOPPING</h1>
									<h2>Free Ecommerce Template</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
									<button type="button" class="btn btn-default get">Get it now</button>
								</div>
								<div class="col-sm-6">
									<img src="<?php echo base_url() ?>asset/images/home/girl3.jpg" class="girl img-responsive" alt="" />
									<img src="<?php echo base_url() ?>asset/images/home/pricing.png" class="pricing" alt="" />
								</div>
							</div>
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>